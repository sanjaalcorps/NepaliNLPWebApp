package np.org.mpp.ocr.nepalifragmenter;

public class CharImage {
	private int colstart;
	private int colend;
	private int rowstart;
	private int rowend;
	private int width;
	private int height;
	private int pixels[];
	private ImageCapsule imgcapsule;
	private int headlinewidth;
	private int headlinestartindex;
	private int linenum;
	private int wordnum;
	private int charnum;
	
	
	public CharImage(ImageCapsule ic){
		this.pixels=ic.getPixels();
		this.width=ic.getWidth();
		this.height=ic.getHeight();
		this.imgcapsule=ic;
	}
	public void setHeadLineWidth(int hlw){
		this.headlinewidth=hlw;
	}
	public void setRowColBoundry(int rowstart, int rowend,int colstart,int colend){
		this.rowend=rowend;
		this.rowstart=rowstart;
		this.colend=colend;
		this.colstart=colstart;
	}
	public void setLineNumWordNumCharNum(int ln,int wn,int cn){
		this.linenum=ln;
		this.wordnum=wn;
		this.charnum=cn;
	}
	public void setHeadLineStartIndex(int hlsi){
		this.headlinestartindex=hlsi;
	}
	public void fragment(){
		int i,j;
		for(i=rowstart;i<=rowstart+this.headlinewidth;++i){
			for(j=this.colend;j<this.colend+this.headlinewidth;++j)
			this.imgcapsule.setData(i*this.width+j, 1);
			
		}
		
	}
	public void split(){
		int i,j;
		for(i=rowstart;i<=rowend;++i){
			for(j=this.colend;j<this.colend+this.headlinewidth;++j)
			this.imgcapsule.setData(i*this.width+j, 1);
			
		}
	}
	public void mark(){
		int i;
		for(i=rowstart;i<=rowend;++i){
			this.imgcapsule.setData(i*this.width+this.colend, 1);
			//this.pixels[i*this.width+this.colend]=0;
		}
	}
	public void printAll(){
		Log.log("rs="+rowstart+" re="+rowend+" cs="+colstart+" ce="+colend);
	}
}
