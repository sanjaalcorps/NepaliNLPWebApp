package np.org.mpp.ocr.nepalifragmenter;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.RenderedImage;
import java.io.File;


import com.asprise.util.tiff.*;
public class ImageReader {
	private String file;
	private int width=0;
	private int height=0;
	private int pixels[];
	private BufferedImage input;
	ImageReader(String file){
		this.file=file;
	}
	public void readAndinit() throws Exception{
		TIFFReader tr=new TIFFReader(new File(this.file));
		RenderedImage ri=tr.getPage(0);
		Raster raster=ri.getData();	
		this.width=ri.getWidth();
		this.height=ri.getHeight();
		this.input = new BufferedImage(ri.getWidth(),ri.getHeight(),BufferedImage.TYPE_INT_RGB);
		this.input.setData(raster);
		BufferedImage im =
			   new BufferedImage(input.getWidth(),input.getHeight(),BufferedImage.TYPE_BYTE_BINARY);
		       // Get the graphics context for the black-and-white image.
		Graphics2D g2d = im.createGraphics();
		       // Render the inp,ut image on it.
		g2d.drawImage(this.input,0,0,null);
		       // Store the resulting image using the PNG format.
		Raster outraster=im.getData();
		this.pixels=new int[im.getWidth()*im.getHeight()];
		this.pixels=outraster.getPixels(0, 0, im.getWidth(), im.getHeight(), this.pixels);
		
		//this.display();
	}
	public void display(){
		int k=0;
	       for(int i=0;i<this.height;++i){
	    	   for(int j=0;j<this.width;++j){
	    		   Log.log(pixels[k++]+"");
	    	   }
	    	   Log.log("\n");
	       }
	}
	public int[] getData(){
		return this.pixels;
	}
	public BufferedImage getImage(){
		return this.input;
	}
	public int getWidth(){return width;}
	public int getHeight(){return height;}

}
