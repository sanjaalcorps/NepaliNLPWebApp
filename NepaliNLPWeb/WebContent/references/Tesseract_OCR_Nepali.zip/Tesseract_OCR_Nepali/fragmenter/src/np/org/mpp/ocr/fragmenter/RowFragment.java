package np.org.mpp.ocr.fragmenter;

public abstract class RowFragment {
	protected int[] pixels;
	protected int rowstart;
	protected int rowend;
	protected int imgw;
	protected int imgh;
	
	
	public RowFragment(int pixels[],int rowstart, int rowend, int imgw,int imgh){
		this.pixels=pixels;
		this.rowend=rowend;
		this.rowstart=rowstart;
		this.imgw=imgw;
		this.imgh=imgh;
	}	
	abstract public void fragment();
	
}
