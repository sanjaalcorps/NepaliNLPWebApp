package np.org.mpp.ocr.nepalifragmenter;

public class ImageCapsule {
	private int pixels[];
	private int height;
	private int width;
	ImageCapsule(int pixels[],int width,int height){
		this.pixels=pixels;
		this.width=width;
		this.height=height;
	}
	public int[] getPixels(){
		return this.pixels;
	}
	public int getHeight(){
		return this.height;
	}
	public int getWidth(){
		return this.width;
	}
	public void setData(int i,int val){
		if(i<this.height*this.width){
			this.pixels[i]=val;
		}
	}
	
	
}
