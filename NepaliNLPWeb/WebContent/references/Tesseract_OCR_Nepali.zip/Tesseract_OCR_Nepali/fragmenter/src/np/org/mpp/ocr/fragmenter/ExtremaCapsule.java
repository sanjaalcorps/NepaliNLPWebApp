package np.org.mpp.ocr.fragmenter;

public class ExtremaCapsule {
	int start;
	int width;
	ExtremaCapsule(int start, int width){
		this.start=start;
		this.width=width;
	}
	public int getPos(){
		return this.start;
	}
	public int getWidth(){
		return this.width;
	}
}
