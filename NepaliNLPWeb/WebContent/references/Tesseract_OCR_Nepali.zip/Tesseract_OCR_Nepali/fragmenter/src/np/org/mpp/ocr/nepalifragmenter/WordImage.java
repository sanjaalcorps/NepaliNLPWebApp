package np.org.mpp.ocr.nepalifragmenter;

import java.util.ArrayList;

public class WordImage {
	private int colstart;
	private int colend;
	private int rowstart;
	private int rowend;
	private int pixels[];
	private int width;
	private int height;
	private int histo[];
	private int horizontalHisto[];
	private ArrayList<CharImage> charImageList;
	//static int count=0;
	private int headlinewidth;
	private int headlinestartindex;
	private ImageCapsule imgcapsule;
	private int linenum;
	private int wordnum;
	
	public int maxrowsize;
	WordImage(ImageCapsule ic,int rowstart,int rowend){
		this.imgcapsule=ic;
		this.pixels=ic.getPixels();
		this.width=ic.getWidth();
		this.height=ic.getHeight();
		this.rowend=rowend;
		this.rowstart=rowstart;
		this.charImageList=new ArrayList<CharImage>();
	}
	public void setLineNumWordNum(int ln, int wn){
		this.linenum=ln;
		this.wordnum=wn;
	}
	public void setColBoundry(int colstart,int colend){
		this.colend=colend;
		this.colstart=colstart;
		this.histo=new int[this.colend-this.colstart+1];
		this.horizontalHisto=new int[this.rowend-this.rowstart+1];
	}
	public void createHisto(){
		int i,j,k=0;
		for(j=colstart;j<=colend;++j){
			this.histo[k]=0;
			for(i=rowstart;i<=rowend;++i){
				if(this.pixels[i*width+j]==0){this.histo[k]++;}
			}
			++k;
		}
	}
	public void createHorizontalHisto(){
		int i,j,k=0;
		for(i=rowstart;i<=rowend;++i){
			this.horizontalHisto[k]=0;
			for(j=colstart;j<=colend;++j){
				if(this.pixels[i*width+j]==0){this.horizontalHisto[k]++;}				
			}
			++k;
		}
	}
	public void evaluateHeadLineWidth(){
		int i;
		int startindex=0;
		int endindex=0;
		boolean flag=false;
		for(i=0;i<this.rowend-this.rowstart+1;++i){
			if(this.horizontalHisto[i]==this.maxrowsize && !flag){
				flag=true;
				startindex=i;
			}
			if(this.horizontalHisto[i]<this.maxrowsize && flag){
				endindex=i;
				break;
			}
		}
		this.headlinewidth=endindex-startindex;
		this.headlinestartindex=this.rowstart+startindex;
		
	}
	
	public void findMaxRowSize(){
		int i;
		this.maxrowsize=this.horizontalHisto[0];
		for(i=1;i<this.rowend-this.rowstart+1;++i){
			if(this.maxrowsize<this.horizontalHisto[i]){
				this.maxrowsize=this.horizontalHisto[i];
			}
		}
		
	}
	public void fragmentChars(){
		int i;
		int startindex=0;
		int endindex=0;
		boolean flag=false;
		CharImage ci=null;
		int count =0;
		for(i=0;i<colend-colstart+1;++i){
			if(this.histo[i]>this.headlinewidth && !flag){
				flag=true;
				startindex=colstart+i-1;
				
			}
			if(this.histo[i]==this.headlinewidth && flag){
				flag=false;
				endindex=colstart+i;
				ci=new CharImage(this.imgcapsule);
				ci.setRowColBoundry(rowstart, rowend, startindex, endindex);
				ci.setHeadLineWidth(this.headlinewidth);
				this.charImageList.add(ci);
				ci.setLineNumWordNumCharNum(this.linenum, this.wordnum, count);
				ci.setHeadLineStartIndex(this.headlinestartindex);
				//System.out.println("ln="+this.linenum+" wn="+this.wordnum+" cn="+count);
				++count;
			
			}
		}
		for(i=0;i<this.charImageList.size()-1;++i){
			
			//this.charImageList.get(i).fragment();
		}
	}
	public void mark(){
		int i;
		for(i=rowstart;i<=rowend;++i){
			this.imgcapsule.setData(i*this.width+this.colend, 0);
			//this.pixels[i*this.width+this.colend]=0;
		}
		for(i=0;i<this.charImageList.size();++i){
			this.charImageList.get(i).mark();
		}
	}
	public ArrayList<CharImage> getCharImgList(){
		return this.charImageList;
	}
	public void printAll(){
		int i;
		Log.log("cs="+this.colstart+"ce="+this.colend);
		for(i=0;i<this.charImageList.size();++i){
			Log.log("char "+i);
			this.charImageList.get(i).printAll();
		}
	}
}
