package np.org.mpp.ocr.fragmenter;

public class Test {

	/**
	 * @param args
	 */
	public static void display(int a[]){
		for(int i=0;i<a.length;++i){
			System.out.print(a[i]+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a[]=new int[20];
        for(int i=0;i<20;++i){
        	a[i]=i;
        }
        int b[]=DSPBasics.getConvulation(a, 5, 10);
        Test.display(b);
	}

}
