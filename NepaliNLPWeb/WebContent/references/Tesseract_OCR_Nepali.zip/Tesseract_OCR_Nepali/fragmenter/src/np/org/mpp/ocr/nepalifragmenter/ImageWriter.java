package np.org.mpp.ocr.nepalifragmenter;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferInt;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.SinglePixelPackedSampleModel;
import java.awt.image.WritableRaster;

import java.io.File;

import com.asprise.util.tiff.*;
public class ImageWriter {
	private String file;
	private int pixels[];
	private int height;
	private int width;
	private BufferedImage input;
	public ImageWriter(String file,int height,int width,int pixels[],BufferedImage input) {
		// TODO Auto-generated constructor stub
		this.file=file;
		this.height=height;
		this.width=width;
		this.pixels=pixels;
		this.input=input;
	}
	public void write()throws Exception{
		DataBuffer dbuf=new DataBufferInt(this.pixels,this.width*this.height,0);
		int bitMasks[] = new int[]{(byte)0xffff};

		SampleModel sampleModel=new SinglePixelPackedSampleModel(DataBuffer.TYPE_INT,this.width,this.height,bitMasks);
		WritableRaster raster=Raster.createWritableRaster(sampleModel, dbuf, null);

		BufferedImage images[]=new BufferedImage[1];
		BufferedImage im =
			   new BufferedImage(this.width,this.height,BufferedImage.TYPE_BYTE_BINARY);
		
		im.setData(raster);
	    images[0]=im;
	    TIFFWriter.createTIFFFromImages(images,TIFFWriter.TIFF_CONVERSION_TO_BLACK_WHITE,TIFFWriter.TIFF_COMPRESSION_NONE,new File(this.file));
	    
	
	}
}
