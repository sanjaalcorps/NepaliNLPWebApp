package np.org.mpp.ocr.nepalifragmenter;
import java.util.ArrayList;
public class LineImage {
	private int rowstart;
	private int rowend;
	int pixels[];
	private int width;
	private int height;
	private int histo[];
	private ImageCapsule imgcaCapsule;
	private int linenum;
	private ArrayList<WordImage> wordImageList;
	LineImage(ImageCapsule ic, int rowstart, int rowend){
		this.imgcaCapsule=ic;
		this.pixels=ic.getPixels();
		this.width=ic.getWidth();
		this.height=ic.getHeight();
		this.rowend=rowend;
		this.rowstart=rowstart;
		this.histo=new int[width];
		this.wordImageList=new ArrayList<WordImage>();
	}
	public void setLineNum(int n){
		this.linenum=n;
	}
	public void createHisto(){
		int i,j,k=0;
		for(j=0;j<width;++j){
			this.histo[k]=0;
			for(i=rowstart;i<=rowend;++i){
				if(this.pixels[i*this.width+j]==0){this.histo[k]++;}
			}
			++k;
		}
	}
	public void fragmentWords(){
		int i;
		int startcol=0,endcol=0;
		boolean flag=false;
		WordImage wi=null;
		int count=0;
		for(i=0;i<width;++i){
			if(this.histo[i]>0 && !flag){
				startcol=i;
				flag=true;
			}
			if(this.histo[i]==0 && flag){
				endcol=i-1;
				flag=false;
				wi=new WordImage(this.imgcaCapsule,rowstart,rowend);
				wi.setColBoundry(startcol, endcol);
				wi.createHisto();
				wi.createHorizontalHisto();
				wi.findMaxRowSize();
				wi.evaluateHeadLineWidth();
				wi.fragmentChars();
				this.wordImageList.add(wi);
				wi.setLineNumWordNum(this.linenum,count);
				++count;
			}
		}
	}
	public ArrayList<WordImage> getWordImageList(){
		return this.wordImageList;
	}
	public void mark(){
		int i;
		for(i=0;i<this.width;++i){
			this.imgcaCapsule.setData(this.rowstart*this.width+i, 0);
		}
		for(i=0;i<this.wordImageList.size();++i){
			this.wordImageList.get(i).mark();
		}
	}
	public void printAll(){
		int i;
		Log.log("rs="+this.rowstart+" re="+this.rowend);
		//System.out.println(this.wordImageList.size());
		for(i=0;i<this.wordImageList.size();++i){
			Log.log("word "+i);
			this.wordImageList.get(i).printAll();
		}
	}
}
