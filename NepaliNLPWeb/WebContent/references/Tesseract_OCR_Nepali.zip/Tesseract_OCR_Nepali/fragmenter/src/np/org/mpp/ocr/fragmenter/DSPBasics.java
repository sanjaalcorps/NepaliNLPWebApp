package np.org.mpp.ocr.fragmenter;

public class DSPBasics {
	public static int[] getConvulation(int arr[],int windowLength, int windowHeight){
		int arrsize=arr.length;
		int size=arr.length+windowLength-1;
		int a[]=new int[size];
		int i,j,k;
		int window[]=new int[windowLength];
		for(i=0;i<windowLength;++i){
			window[i]=windowHeight;
		}
		int wstart=-(windowLength-1);
		int wend=0;
		int sum;
		for(i=0;i<size;++i){
			sum=0;
			k=0;
			for(j=wstart;j<=wend;++j){
				if(j>=0 && j<arrsize){
					sum+=window[k]*arr[j];
				}
				++k;
			}
			a[i]=sum;
			++wstart;
			++wend;
		}		
		return a;
	}
}
