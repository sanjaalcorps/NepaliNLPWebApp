package np.org.mpp.ocr.fragmenter;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import com.asprise.util.tiff.TIFFReader;

public class ImgReader {
	private int pixels[];
	private Raster outraster;
	private BufferedImage output;
	public File file;
		ImgReader(File file)throws IOException{
		this.file=file;
		try{
			this.init();
		}
		catch(IOException e){
			throw e;
		}
	}
	private void init()throws IOException{
		TIFFReader tr=new TIFFReader(this.file);
		RenderedImage ri=tr.getPage(0);
		Raster raster=ri.getData();
		
		BufferedImage images[]=new BufferedImage[1];
		
		BufferedImage input = new BufferedImage(ri.getWidth(),ri.getHeight(),BufferedImage.TYPE_INT_RGB);
		input.setData(raster);
		Graphics2D g=input.createGraphics();
		this.output=new BufferedImage(ri.getWidth(),ri.getHeight(),BufferedImage.TYPE_BYTE_BINARY);
		g.drawImage(input,0,0,null);
	}
	//public int[] getData(){
		//this.outraster.getPixels(r, y, w, h, iArray);
	//}
	
	

}
