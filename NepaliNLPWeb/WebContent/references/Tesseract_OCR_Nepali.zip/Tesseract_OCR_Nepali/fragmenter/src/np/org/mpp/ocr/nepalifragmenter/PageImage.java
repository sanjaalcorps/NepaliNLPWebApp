package np.org.mpp.ocr.nepalifragmenter;
import java.util.ArrayList;
public class PageImage {
	private int histo[];
	private int pixels[];
	private int width;
	private int height;
	ImageCapsule imgcapsule;
	private ArrayList<LineImage> lineImageList;
	public PageImage(ImageCapsule ic){
		this.imgcapsule=ic;
		this.pixels=ic.getPixels();
		this.width=ic.getWidth();
		this.height=ic.getHeight();
		this.lineImageList=new ArrayList<LineImage>();
		this.histo=new int[this.height];
	}
	public void createHisto(){
		int i,j,k=0;
		for(i=0;i<this.height;++i){
			this.histo[i]=0;
			for(j=0;j<this.width;++j){
				if(this.pixels[k]==0){++this.histo[i];}
				++k;
			}
		}
	}
	public void fragment(){
		this.fragmentLines();
	}
	public void fragmentLines(){
		int linecount=0;
		int i;
		boolean flag=false;
		int startrow=0;
		int endrow=0;
		LineImage li=null;
		int count=0;
		for(i=0;i<this.height;++i){
			if(this.histo[i]>0 && !flag){
				startrow=i;
				flag=true;
			}
			if(flag && this.histo[i]==0){
				endrow=i-1;
				flag=false;
				++linecount;
				//add line image
				li=new LineImage(this.imgcapsule,startrow,endrow);
				li.createHisto();				
				this.lineImageList.add(li);
				li.setLineNum(count);
				++count;
			}
		}		
		for(i=0;i<this.lineImageList.size();++i){
			this.lineImageList.get(i).fragmentWords();
		}
	}
	public void split(){
		ArrayList<WordImage> wi;
		ArrayList<CharImage> ci;
		for(int i=0;i<this.lineImageList.size();++i){
			wi=this.lineImageList.get(i).getWordImageList();
			for(int j=0;j<wi.size();++j){
				ci=wi.get(j).getCharImgList();
				for(int k=0;k<ci.size()-1;++k){
					ci.get(k).split();
				}
			}
		}
		
	}
	public void mark(){
		int i;
		for(i=0;i<this.lineImageList.size();++i){
			this.lineImageList.get(i).mark();
		}
	}
	public void printall(){
		int i;		
		for(i=1;i<this.lineImageList.size();++i){
			Log.log("line "+i);
			this.lineImageList.get(i).printAll();
			Log.log("\n");
		}
	}
}
	

