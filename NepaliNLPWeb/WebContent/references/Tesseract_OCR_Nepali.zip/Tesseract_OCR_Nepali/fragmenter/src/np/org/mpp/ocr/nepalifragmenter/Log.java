package np.org.mpp.ocr.nepalifragmenter;

import java.io.File;
import java.io.PrintStream;

public class Log {
	static int count=0;
	static PrintStream ps=null;
	public static void log(String msg){
		if(count!=0){
			ps.print(msg);
		}
		else{
			try{
			ps=new PrintStream(new File("log.txt"));
			ps.print(msg);
			++count;
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
	}
}
