package np.org.mpp.ocr.fragmenter;
import java.util.ArrayList;
public class RowFragmentHisto extends RowFragment {
	public int histo[];
	public int histoAvgPixDistribution[];
	private int convolve[];
	public ArrayList<ExtremaCapsule> mininaList;
	private int thresMin;
	private int headLineRow;
	
	
	public RowFragmentHisto(int pixels[], int rowstart, int rowend, int imgw, int imgh){
		super(pixels,rowstart,rowend,imgw,imgh);
		this.mininaList=new ArrayList<ExtremaCapsule>();
	}
	public void createHisto(){
		int j,i;
		int count;
		this.histo=new int[imgw];
		//int avgrowdistribution;
		int sum;
		this.histoAvgPixDistribution=new int[imgw];
		for(j=0;j<imgw;++j){
			count=0;
			sum=0;
			for(i=rowstart;i<=rowend;++i){
				if(pixels[i*imgw+j]!=0){
					++count;
					sum+=i;
				}
				
			}
			histo[j]=count;
			this.histoAvgPixDistribution[j]=sum;
		}
		this.convolve=DSPBasics.getConvulation(this.histo, 5, rowend-rowstart);
	}
	public void findMinimas(){
		int start=0;
		int end=0;
		boolean ridgefound=false;
		ExtremaCapsule ec=null;
		int i;
		for(i=0;i<this.convolve.length-1;++i){
			if(this.convolve[i-1]>this.convolve[i] && this.convolve[i]>this.convolve[i+1]){
				ec=new ExtremaCapsule(i,1);
				this.mininaList.add(ec);
				ridgefound=false;
			}
			else if(this.convolve[i-1]>this.convolve[i] && this.convolve[i]==this.convolve[i+1] && !ridgefound){
				start=i;
				ridgefound=true;
			}
			else if(this.convolve[i-1]==this.convolve[i] && this.convolve[i]<this.convolve[i+1] && ridgefound){
				end=i;
				ec=new ExtremaCapsule(start,end-start);
				this.mininaList.add(ec);
				ridgefound=false;
			}
		}
	}
	public void findHeadLineRow(){
		int verHisto[]=new int[rowend-rowstart+1];
		int i,j,count;
		for(i=rowstart;i<=rowend;++i){
			count=0;
			for(j=0;j<imgw;++j){
				if(pixels[i*imgw+j]!=0){
					++count;
				}
			}
			verHisto[i]=count;
		}
		int verHistoConv[]=DSPBasics.getConvulation(verHisto, 3, (rowend-rowstart)/4);
		int max=0;
		int indx=0;
		for(i=1;i<verHistoConv.length-1;++i){
			if(verHistoConv[i-1]<verHistoConv[i] && verHistoConv[i]>verHistoConv[i+1] ){
				if(verHistoConv[i]>max){
					max=verHistoConv[i];
					indx=i;
				}
			}
		}
		this.headLineRow=indx+rowstart;		
	}
	@Override
	public void fragment() {
		// TODO Auto-generated method stub

	}

}
