package np.org.mpp.ocr.nepalifragmenter;

public class Main {
	public static void main(String args[])throws Exception{
		
		ImageReader ir=new ImageReader(args[0]);
		ir.readAndinit();
		ImageCapsule imgcapsule=new ImageCapsule(ir.getData(),ir.getWidth(),ir.getHeight());
		
		PageImage pi=new PageImage(imgcapsule);
		pi.createHisto();
		pi.fragment();
		//pi.printall();
		//pi.mark();
		pi.split();
		ImageWriter iw=new ImageWriter(args[1],ir.getHeight(),ir.getWidth(),ir.getData(),ir.getImage());
		iw.write();
	}
	public static void display(int data[],int w, int h){
		int i,j,k=0;
		
		for(i=0;i<h;++i){
			for(j=0;j<w;++j){				
				Log.log(""+data[k++]);
			}
			Log.log("\n");
		
		}
		System.out.println(w+"     "+h);
	}
}
